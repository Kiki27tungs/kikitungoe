import streamlit as st
from streamlit_option_menu import option_menu
from PIL import Image
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import plotly.express as px
from googletrans import Translator
from gtts import gTTS
import io
import base64
import tensorflow as tf

# -------- Load your model once --------
@st.cache_resource
def load_model():
    # Replace this path with your actual model file path
    return tf.keras.models.load_model("plant_disease_classifier.h5") 

model = load_model()

# -------- Your model's class names --------
class_names = [
    "brown_leaves",
    "fungal_spots",
    "hole_leaves",
    "healthy",
]

# -------- Plant issue to diagnosis & advice mapping --------
plant_issues_dict = {
    "brown_leaves": ("Leaf Burn", "Reduce direct sunlight and improve watering."),
    "fungal_spots": ("Fungal Disease", "Apply fungicide and remove infected leaves."),
    "hole_leaves": ("Insect Damage", "Use pesticide spray during early morning."),
    "healthy": ("Healthy Leaf", "No action needed."),
}

# -------- Supported languages for translation --------
languages = {
    "English": "en",
    "Hindi": "hi",
}

# -------- Language dictionaries for UI texts --------
ui_texts = {
    "English": {
        "menu_title": "🌿 AI Farmer Menu",
        "welcome_title": "🌱 Welcome to AI Farmer Assistant",
        "welcome_subtitle": "Empowering Farmers with AI. Diagnose, Plan, and Grow Smartly.",
        "ai_assistant_title": "🤖 AI Farmer Assistant Dashboard",
        "name_label": "Name",
        "language_label": "Language",
        "weather_label": "Weather Condition",
        "soil_label": "Soil Type",
        "upload_label": "Upload Crop Leaf Image",
        "diagnosis_advice_title": "🧠 Diagnosis & Advice",
        "user_input_summary": "📋 User Input Summary",
        "download_csv": "📥 Download Summary as CSV",
        "info_no_upload": "Please upload a crop leaf image to get diagnosis and advice.",
        "developed_by": "👨‍🔬 Developed by Green Rebels",
        "crop_calendar_title": "📆 Crop Planting and Harvesting Calendar",
        "crop_stats_title": "📊 Crop Statistics and Insights",
        "weather_options": ["Select", "Sunny", "Rainy", "Cloudy", "Windy", "Humid"],
        "soil_options": ["Select", "Soft Black Soil", "Hard Dry Soil", "Wet Muddy Soil",
                         "Sandy Loose Soil", "Sticky Clay Soil", "Red Dry Soil"],
    },
    "Hindi": {
        "menu_title": "🌿 एआई किसान मेनू",
        "welcome_title": "🌱 एआई किसान सहायक में आपका स्वागत है",
        "welcome_subtitle": "किसानों को सशक्त बनाना। AI के साथ निदान, योजना बनाएं और स्मार्टली उगाएं।",
        "ai_assistant_title": "🤖 एआई किसान सहायक डैशबोर्ड",
        "name_label": "नाम",
        "language_label": "भाषा",
        "weather_label": "मौसम की स्थिति",
        "soil_label": "मिट्टी का प्रकार",
        "upload_label": "फसल के पत्ते की छवि अपलोड करें",
        "diagnosis_advice_title": "🧠 निदान और सलाह",
        "user_input_summary": "📋 उपयोगकर्ता इनपुट सारांश",
        "download_csv": "📥 CSV के रूप में सारांश डाउनलोड करें",
        "info_no_upload": "निदान और सलाह प्राप्त करने के लिए कृपया फसल की पत्तियों की छवि अपलोड करें।",
        "developed_by": "👨‍🔬 डेवलपेड बाय ग्रीन रेबेल्स",
        "crop_calendar_title": "📆 फसल लगाना और कटाई कैलेंडर",
        "crop_stats_title": "📊 फसल सांख्यिकी और अंतर्दृष्टि",
        "weather_options": ["चुनें", "धूप", "बारिश", "बादल", "हवा", "आर्द्र"],
        "soil_options": ["चुनें", "नरम काली मिट्टी", "कड़ी सूखी मिट्टी", "गीली कीचड़ वाली मिट्टी",
                         "रेतीली ढीली मिट्टी", "चिपचिपी चिकनी मिट्टी", "लाल सूखी मिट्टी"],
    },
}

# ----------- Background and Styling ------------
background_url = "https://img.freepik.com/premium-photo/plant-is-growing-out-chip-circuit-board_890960-132.jpg"

st.markdown(
    f"""
    <style>
    [data-testid="stAppViewContainer"] {{
        background: linear-gradient(rgba(0, 0, 0, 0.75), rgba(0, 0, 0, 0.75)), url({background_url});
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
    }}
    [data-testid="stSidebar"] {{
        background-color: #1a472a;
        color: white;
    }}
    [data-testid="stSidebar"] * {{
        color: white !important;
    }}
    h1, h2, h3, h4, h5, p, label, div {{
        color: white !important;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }}
    a {{
        color: #90ee90;
    }}
    .stButton>button {{
        background-color: #2e7d32;
        color: white;
        font-weight: bold;
    }}
    .stButton>button:hover {{
        background-color: #4caf50;
        color: white;
    }}
    .css-1cpxqw2, .css-1hwfws3, .css-14xtw13, .css-1g6gooi {{
        color: black !important;
    }}
    </style>
    """,
    unsafe_allow_html=True,
)

# --------- Language selection in sidebar ---------
with st.sidebar:
    selected_lang = st.selectbox("🌐 Select Language / भाषा चुनें", options=list(ui_texts.keys()), index=0)

texts = ui_texts.get(selected_lang, ui_texts["English"])  # fallback to English

# --------- Sidebar menu ---------
with st.sidebar:
    selected_menu = option_menu(
        menu_title=texts["menu_title"],
        options=[
            texts["welcome_title"],
            texts["ai_assistant_title"],
            texts["crop_calendar_title"],
            texts["crop_stats_title"],
        ],
        icons=["house", "robot", "calendar", "bar-chart"],
        default_index=0,
        styles={
            "container": {"padding": "5px", "background-color": "#1a472a"},
            "icon": {"color": "#90ee90", "font-size": "20px"},
            "nav-link": {
                "font-size": "16px",
                "text-align": "left",
                "margin": "5px 0",
                "color": "white",
                "font-weight": "bold",
            },
            "nav-link-selected": {"background-color": "#2e7d32", "color": "white"},
        },
    )
    st.markdown("---")
    st.markdown(
        f"<p style='text-align:center;color:#90ee90;font-weight:bold;'>{texts['developed_by']}</p>",
        unsafe_allow_html=True,
    )

# --------- Welcome Page ---------
if selected_menu == texts["welcome_title"]:
    st.markdown(
        f"""
        <div style="height: 60vh; display:flex; flex-direction:column; justify-content:center; align-items:center; text-align:center;">
            <h1 style="font-size:3.5rem; margin-bottom: 0.2rem;">{texts['welcome_title']}</h1>
            <p style="font-size:1.5rem; max-width:700px;">{texts['welcome_subtitle']}</p>
        </div>
        """,
        unsafe_allow_html=True,
    )

# --------- AI Assistant Page ---------
elif selected_menu == texts["ai_assistant_title"]:
    st.markdown(f"<h1 style='text-align:center;'>{texts['ai_assistant_title']}</h1>")

    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        name = st.text_input(texts["name_label"])
        weather = st.selectbox(texts["weather_label"], texts["weather_options"])
        soil = st.selectbox(texts["soil_label"], texts["soil_options"])

        uploaded_file = st.file_uploader(texts["upload_label"], type=["jpg", "jpeg", "png"])

        if uploaded_file:
            image = Image.open(uploaded_file)
            st.image(image, caption="Uploaded Image", width=350)

            # Prediction with thresholding and debug output
            def predict_conditions(image, threshold=0.15):
                img = image.convert("RGB").resize((224, 224))
                img_array = np.array(img) / 255.0
                img_array = np.expand_dims(img_array, axis=0)

                preds = model.predict(img_array)[0]
                pred_dict = {class_names[i]: float(preds[i]) for i in range(len(class_names))}

                # Show raw prediction probabilities for debugging
                st.write("Raw prediction probabilities:", pred_dict)

                detected = [class_names[i] for i, p in enumerate(preds) if p > threshold]
                if not detected:
                    max_idx = np.argmax(preds)
                    detected = [class_names[max_idx]]
                return detected, pred_dict

            predicted_conditions, raw_preds = predict_conditions(image)

            problems = []
            solutions = []
            for cond in predicted_conditions:
                prob = raw_preds.get(cond, 0)
                problem, solution = plant_issues_dict.get(cond, ("Unknown Condition", "No advice available."))
                problems.append(f"{problem} ({prob:.2f})")
                solutions.append(solution)

            combined_problem = ", ".join(problems)
            combined_solution = " ".join(solutions)

            # Watering advice based on weather
            if weather == "Rainy" or weather == "बारिश":
                watering = "Reduce watering as rain provides moisture."
            elif weather == "Sunny" or weather == "धूप":
                watering = "Water early morning and evening to prevent evaporation."
            else:
                watering = "Ensure consistent watering based on crop needs."

            summary_text = f"Problems detected: {combined_problem}. Solutions: {combined_solution}. Watering Advice: {watering}"

            translator = Translator()
            try:
                translated = translator.translate(summary_text, dest=languages[selected_lang]).text
            except Exception:
                translated = summary_text  # fallback

            st.markdown(f"#### 🌿 Detected Condition(s): **{', '.join(predicted_conditions)}**")
            st.markdown(f"🛑 **Diagnosis:** {combined_problem}")
            st.markdown(f"✅ **Advice:** {combined_solution}")
            st.markdown(f"💧 **Watering Advice:** {watering}")

            st.markdown(f"🌐 **Translated Summary in {selected_lang}:**")
            st.info(translated)

            tts = gTTS(translated, lang=languages[selected_lang])
            audio_fp = io.BytesIO()
            tts.write_to_fp(audio_fp)
            audio_fp.seek(0)
            st.audio(audio_fp.read(), format="audio/mp3")

            summary_csv = "Name,Language,Weather,Soil,Conditions,Diagnosis,Advice,Watering Advice\n"
            summary_csv += f"{name},{selected_lang},{weather},{soil},\"{'|'.join(predicted_conditions)}\",\"{combined_problem}\",\"{combined_solution}\",\"{watering}\"\n"

            b64 = base64.b64encode(summary_csv.encode()).decode()
            href = f'<a href="data:file/csv;base64,{b64}" download="farmer_summary.csv">{texts["download_csv"]}</a>'
            st.markdown(href, unsafe_allow_html=True)
        else:
            st.info(texts["info_no_upload"])

        # Summary section
        st.markdown(f"### {texts['user_input_summary']}")
        st.write(f"**{texts['name_label']}:** {name}")
        st.write(f"**{texts['language_label']}:** {selected_lang}")
        st.write(f"**{texts['weather_label']}:** {weather}")
        st.write(f"**{texts['soil_label']}:** {soil}")
        if uploaded_file:
            st.image(image, width=200)

# --------- Crop Calendar Page ---------
elif selected_menu == texts["crop_calendar_title"]:
    st.markdown(f"<h1 style='text-align: center;'>{texts['crop_calendar_title']}</h1>")

    crop_timeline = {
        "Tomato": {"Planting": "2025-06-01", "Harvesting": "2025-09-15"},
        "Wheat": {"Planting": "2025-11-01", "Harvesting": "2026-03-10"},
        "Rice": {"Planting": "2025-07-01", "Harvesting": "2025-11-10"},
        "Maize": {"Planting": "2025-05-10", "Harvesting": "2025-09-20"},
        "Sugarcane": {"Planting": "2025-02-01", "Harvesting": "2026-01-15"},
        "Cotton": {"Planting": "2025-06-20", "Harvesting": "2025-11-30"},
    }

    df_timeline = pd.DataFrame(
        [
            {"Crop": crop, "Start": info["Planting"], "Finish": info["Harvesting"]}
            for crop, info in crop_timeline.items()
        ]
    )
    fig = px.timeline(
        df_timeline,
        x_start="Start",
        x_end="Finish",
        y="Crop",
        color="Crop",
        color_discrete_sequence=px.colors.sequential.Greens,
    )
    fig.update_yaxes(autorange="reversed")
    st.plotly_chart(fig, use_container_width=True)

# --------- Crop Stats Page ---------
elif selected_menu == texts["crop_stats_title"]:
    st.markdown(f"<h1 style='text-align: center;'>{texts['crop_stats_title']}</h1>")

    crop_data = pd.DataFrame(
        {
            "Crop": ["Wheat", "Rice", "Maize", "Sugarcane", "Cotton"],
            "Production (tons)": [28, 34, 15, 52, 25],
            "Area (hectares)": [22, 30, 18, 55, 27],
            "Fertilizer (kg/acre)": [40, 50, 35, 25, 38],
            "Water Usage (litres/acre)": [3000, 3500, 2500, 4000, 2000],
            "Profit (₹/acre)": [12000, 15000, 9000, 18000, 10000],
        }
    )

    plt.rcParams.update({"font.size": 9})
    figsize = (4.5, 3.5)

    def generate_figures():
        figs = []

        fig1, ax1 = plt.subplots(figsize=figsize)
        ax1.bar(crop_data["Crop"], crop_data["Production (tons)"], color="#388e3c")
        ax1.set_title("🌱 Production")
        figs.append(fig1)

        fig2, ax2 = plt.subplots(figsize=figsize)
        ax2.plot(crop_data["Crop"], crop_data["Area (hectares)"], marker="o", color="#0288d1")
        ax2.set_title("🌾 Area Used")
        figs.append(fig2)

        fig3, ax3 = plt.subplots(figsize=figsize)
        ax3.barh(crop_data["Crop"], crop_data["Fertilizer (kg/acre)"], color="#fbc02d")
        ax3.set_title("💊 Fertilizer Usage")
        figs.append(fig3)

        fig4, ax4 = plt.subplots(figsize=(4, 4))
        ax4.pie(
            crop_data["Water Usage (litres/acre)"],
            labels=crop_data["Crop"],
            autopct="%1.1f%%",
            startangle=90,
            colors=["#4db6ac", "#ff7043", "#aed581", "#ba68c8", "#64b5f6"],
        )
        ax4.set_title("💧 Water Share")
        figs.append(fig4)

        fig5, ax5 = plt.subplots(figsize=figsize)
        ax5.bar(crop_data["Crop"], crop_data["Profit (₹/acre)"], color="#e53935")
        ax5.set_title("💰 Profit per Acre")
        figs.append(fig5)

        fig6, ax6 = plt.subplots(figsize=figsize)
        ax6.bar(
            crop_data["Crop"], crop_data["Production (tons)"], alpha=0.5, label="Production", color="#81d4fa"
        )
        ax6.plot(
            crop_data["Crop"],
            crop_data["Profit (₹/acre)"],
            marker="o",
            color="#d32f2f",
            label="Profit",
            linewidth=2,
        )
        ax6.set_title("📊 Production vs Profit")
        ax6.legend()
        figs.append(fig6)

        return figs

    figs = generate_figures()
    col1, col2, col3 = st.columns(3)
    with col1:
        st.pyplot(figs[0])
        st.pyplot(figs[3])
    with col2:
        st.pyplot(figs[1])
        st.pyplot(figs[4])
    with col3:
        st.pyplot(figs[2])
        st.pyplot(figs[5])
