import streamlit as st
from PIL import Image
import os
from googletrans import Translator
from gtts import gTTS
import io
import base64
import pandas as pd
import matplotlib.pyplot as plt

# -------------------- Title --------------------
st.set_page_config(page_title="AI Farmer Assistant", layout="wide")
st.title("🌾 AI Farmer Assistant Dashboard")

# -------------------- Sidebar --------------------
st.sidebar.header("👨‍🌾 Farmer Input Panel")

# Language Selection
languages = {
    "English": "en",
    "Hindi": "hi",
    "Assamese": "as",
    "Bengali": "bn",
    "Telugu": "te",
    "Tamil": "ta"
}
selected_lang = st.sidebar.selectbox("Language Selection", options=list(languages.keys()))

# User Info
name = st.sidebar.text_input("Name")
issue = st.sidebar.selectbox("Issue", ["Select", "Leaf Disease", "Pest Attack", "Nutrient Deficiency"])
weather = st.sidebar.selectbox("Weather", ["Select", "Sunny", "Rainy", "Cloudy", "Windy"])
soil = st.sidebar.selectbox("Soil Type", ["Select", "Loamy", "Sandy", "Clay", "Silt", "Peaty"])

# -------------------- Image Upload --------------------
st.sidebar.markdown("### Upload Leaf Image")
uploaded_file = st.sidebar.file_uploader("Upload Image", type=["jpg", "png", "jpeg"])

if uploaded_file:
    image = Image.open(uploaded_file)
    st.image(image, caption="Uploaded Image", use_column_width=True)
else:
    st.warning("Please upload a crop image to analyze.")

# -------------------- Main Output --------------------
st.markdown("### 🔍 Prediction and Advice")

# Dummy prediction logic
def dummy_predict(issue_type):
    if issue_type == "Leaf Disease":
        return {
            "problem": "Leaf Blight Detected",
            "solution": "Use copper-based fungicide twice a week.",
            "watering": "Water in early morning and avoid wetting leaves."
        }
    elif issue_type == "Pest Attack":
        return {
            "problem": "Aphid Infestation",
            "solution": "Spray neem oil or insecticidal soap.",
            "watering": "Keep soil moist but avoid overwatering."
        }
    elif issue_type == "Nutrient Deficiency":
        return {
            "problem": "Nitrogen Deficiency",
            "solution": "Apply urea-based fertilizer.",
            "watering": "Water immediately after fertilizing."
        }
    else:
        return {
            "problem": "No issue detected.",
            "solution": "Healthy plant.",
            "watering": "Continue regular watering schedule."
        }

if issue != "Select":
    output = dummy_predict(issue)

    st.markdown(f"**Prediction: {output['problem']}**")
    st.markdown(f"**Solution:** {output['solution']}")
    st.markdown(f"**Watering Advice:** {output['watering']}")

    # Translation
    translator = Translator()
    translated_text = translator.translate(
        f"Problem: {output['problem']}\nSolution: {output['solution']}\nWatering Advice: {output['watering']}",
        dest=languages[selected_lang]
    ).text

    st.markdown(f"**Translated Summary in {selected_lang}:**")
    st.info(translated_text)

    # Text to Speech
    tts = gTTS(translated_text, lang=languages[selected_lang])
    audio_fp = io.BytesIO()
    tts.write_to_fp(audio_fp)
    audio_fp.seek(0)

    st.audio(audio_fp.read(), format='audio/mp3')

else:
    st.info("Please select an issue type to get prediction.")

# -------------------- User Summary --------------------
with st.expander("📄 User Summary"):
    st.write(f"**Name:** {name}")
    st.write(f"**Selected Language:** {selected_lang}")
    st.write(f"**Weather Condition:** {weather}")
    st.write(f"**Soil Type:** {soil}")
    st.write(f"**Issue:** {issue}")
    if uploaded_file:
        st.image(image, width=100)

# -------------------- Crop Planting Calendar --------------------
with st.expander("📅 Crop Planting Calendar"):
    st.write("🌱 Here's a dummy planting schedule:")
    calendar = {
        "January": "Wheat",
        "February": "Peas",
        "March": "Corn",
        "April": "Rice",
        "May": "Soybean",
        "June": "Cotton",
        "July": "Millet",
        "August": "Sugarcane",
        "September": "Barley",
        "October": "Potato",
        "November": "Mustard",
        "December": "Chickpeas"
    }
    df = pd.DataFrame(list(calendar.items()), columns=["Month", "Crop"])
    st.dataframe(df)

# -------------------- Visual Charts --------------------
with st.expander("📊 Visual Charts"):
    st.write("Crop Yield Dummy Data")
    chart_data = pd.DataFrame({
        'Crop': ['Wheat', 'Rice', 'Maize', 'Cotton'],
        'Yield (tons)': [3.5, 4.2, 2.8, 1.9]
    })

    fig, ax = plt.subplots()
    ax.bar(chart_data['Crop'], chart_data['Yield (tons)'], color='green')
    ax.set_ylabel('Yield (tons)')
    ax.set_title('Average Yield per Crop')
    st.pyplot(fig)
#---------------------------------------------------------------------------------------------------------------------------------------------
import streamlit as st
from PIL import Image
import pandas as pd
import plotly.express as px
from googletrans import Translator
from gtts import gTTS
import io
import matplotlib.pyplot as plt

# -------------------- Page Setup --------------------
st.set_page_config(page_title="AI Farmer Assistant", layout="wide")
st.title("🌾 AI Farmer Assistant Dashboard")

# -------------------- Sidebar Inputs --------------------
st.sidebar.header("👨‍🌾 Farmer Input Panel")

languages = {
    "English": "en", "Hindi": "hi", "Assamese": "as", "Bengali": "bn", "Gujarati": "gu", "Kannada": "kn",
    "Konkani": "kok", "Malayalam": "ml", "Marathi": "mr", "Odia": "or", "Punjabi": "pa", "Tamil": "ta",
    "Telugu": "te", "Urdu": "ur", "Santali": "sat"
}
selected_lang = st.sidebar.selectbox("Language Selection", options=list(languages.keys()))

name = st.sidebar.text_input("Name")

issue = st.sidebar.selectbox("Select Plant Condition", [
    "Select", "Worms on Leaf", "Brown Leaves", "Dark Spots", "Holes in Leaves", "Yellowing",
    "Wilting", "Leaf Curl", "Stunted Growth", "Mold or Mildew"
])

weather = st.sidebar.selectbox("Weather Condition", ["Select", "Sunny", "Rainy", "Cloudy", "Windy", "Humid"])

soil = st.sidebar.selectbox("Soil Type", [
    "Select", "Soft Black Soil", "Hard Dry Soil", "Wet Muddy Soil",
    "Sandy Loose Soil", "Sticky Clay Soil", "Red Dry Soil"
])

uploaded_file = st.sidebar.file_uploader("Upload Crop Leaf Image", type=["jpg", "jpeg", "png"])

if uploaded_file:
    image = Image.open(uploaded_file)
    st.sidebar.image(image, caption="Uploaded Image", width=220)
else:
    st.sidebar.warning("Please upload an image to proceed.")

# -------------------- Prediction Section --------------------
st.markdown("### 🔍 Prediction and Farming Advice")

def predict_from_issue(issue_type):
    mapping = {
        "Worms on Leaf": ("Worm Infestation", "Use organic insecticide like neem oil."),
        "Brown Leaves": ("Leaf Burn", "Reduce direct sunlight and improve watering."),
        "Dark Spots": ("Fungal Disease", "Apply fungicide and remove infected leaves."),
        "Holes in Leaves": ("Insect Damage", "Use pesticide spray during early morning."),
        "Yellowing": ("Nitrogen Deficiency", "Add compost or urea-based fertilizer."),
        "Wilting": ("Root Rot", "Improve drainage and avoid overwatering."),
        "Leaf Curl": ("Viral Infection", "Remove affected leaves and use antiviral spray."),
        "Stunted Growth": ("Nutrient Deficiency", "Add organic manure or balanced fertilizer."),
        "Mold or Mildew": ("Powdery Mildew", "Apply sulfur-based fungicide.")
    }
    return mapping.get(issue_type, ("Healthy Leaf", "No action needed."))

if issue != "Select":
    problem, solution = predict_from_issue(issue)
    watering = "Ensure consistent watering based on weather and crop needs."

    st.markdown(f"**Prediction:** {problem}")
    st.markdown(f"**Solution:** {solution}")
    st.markdown(f"**Watering Advice:** {watering}")

    translator = Translator()
    summary_text = f"Problem: {problem}\nSolution: {solution}\nWatering Advice: {watering}"
    translated = translator.translate(summary_text, dest=languages[selected_lang]).text

    st.markdown(f"**Translated Summary in {selected_lang}:**")
    st.info(translated)

    tts = gTTS(translated, lang=languages[selected_lang])
    audio_fp = io.BytesIO()
    tts.write_to_fp(audio_fp)
    audio_fp.seek(0)
    st.audio(audio_fp.read(), format='audio/mp3')
else:
    st.info("Please select a plant condition to receive suggestions.")

# -------------------- User Summary --------------------
with st.expander("📄 User Summary"):
    st.write(f"**Name:** {name}")
    st.write(f"**Language:** {selected_lang}")
    st.write(f"**Weather Condition:** {weather}")
    st.write(f"**Soil Type:** {soil}")
    st.write(f"**Plant Condition:** {issue}")
    if uploaded_file:
        st.image(image, width=120)

# -------------------- 📅 Live Crop Planting & Harvesting Chart --------------------
with st.expander("📆 Crop Planting and Harvesting Calendar (Live Chart)"):
    st.markdown("Hover over the bars to see crop details.")

    crop_timeline = {
        "Tomato": {"Planting": "2025-06-01", "Harvesting": "2025-09-15"},
        "Wheat": {"Planting": "2025-11-01", "Harvesting": "2026-03-10"},
        "Rice": {"Planting": "2025-07-01", "Harvesting": "2025-11-10"},
        "Potato": {"Planting": "2025-04-15", "Harvesting": "2025-08-01"},
        "Corn": {"Planting": "2025-05-10", "Harvesting": "2025-09-20"},
        "Sugarcane": {"Planting": "2025-02-01", "Harvesting": "2026-01-15"},
        "Cotton": {"Planting": "2025-06-20", "Harvesting": "2025-11-30"},
        "Chili": {"Planting": "2025-03-15", "Harvesting": "2025-07-30"},
        "Barley": {"Planting": "2025-10-10", "Harvesting": "2026-02-28"},
        "Soybean": {"Planting": "2025-05-25", "Harvesting": "2025-09-15"},
        "Mustard": {"Planting": "2025-09-15", "Harvesting": "2026-01-20"},
        "Green Peas": {"Planting": "2025-10-05", "Harvesting": "2026-01-10"},
        "Cauliflower": {"Planting": "2025-08-10", "Harvesting": "2025-12-05"},
        "Onion": {"Planting": "2025-03-01", "Harvesting": "2025-07-15"},
        "Carrot": {"Planting": "2025-07-10", "Harvesting": "2025-11-01"},
        "Cabbage": {"Planting": "2025-09-05", "Harvesting": "2026-01-15"},
        "Brinjal": {"Planting": "2025-05-20", "Harvesting": "2025-10-01"},
        "Pumpkin": {"Planting": "2025-04-20", "Harvesting": "2025-08-30"},
        "Okra": {"Planting": "2025-06-15", "Harvesting": "2025-10-05"},
        "Lentils": {"Planting": "2025-10-01", "Harvesting": "2026-01-25"}
    }

    df_timeline = pd.DataFrame([
        {"Crop": crop, "Start": info["Planting"], "Finish": info["Harvesting"]}
        for crop, info in crop_timeline.items()
    ])

    fig = px.timeline(
        df_timeline,
        x_start="Start",
        x_end="Finish",
        y="Crop",
        color="Crop",
        color_discrete_sequence=px.colors.qualitative.Safe,
        hover_data={"Start": True, "Finish": True}
    )
    fig.update_yaxes(autorange="reversed")
    fig.update_layout(
        title="🌱 Crop Planting and Harvesting Calendar",
        height=850,
        font=dict(family="Verdana", size=14),
        margin=dict(l=100, r=40, t=90, b=60)
    )
    st.plotly_chart(fig, use_container_width=True)

# -------------------- Charts --------------------
with st.expander("📊 Crop Stats and Charts"):
    st.subheader("🌾 Production vs Area (Dummy Data)")
    data = pd.DataFrame({
        "Crop": ["Wheat", "Rice", "Cotton", "Sugarcane"],
        "Production (tons)": [28, 34, 15, 52],
        "Area (hectares)": [22, 30, 18, 55]
    })
    fig1, ax1 = plt.subplots(figsize=(2, 2))
    ax1.bar(data["Crop"], data["Production (tons)"], color="green", label="Production")
    ax1.plot(data["Crop"], data["Area (hectares)"], marker='o', color='red', label="Area")
    ax1.set_ylabel("Quantity")
    ax1.set_title("Crop Yield Comparison")
    ax1.legend()
    st.pyplot(fig1)

    st.subheader("🌱 Fertilizer Usage per Crop")
    fert_data = pd.DataFrame({
        "Crop": ["Wheat", "Rice", "Maize", "Cotton"],
        "Fertilizer (kg/acre)": [40, 50, 35, 25]
    })
    fig2, ax2 = plt.subplots(figsize=(2, 2))
    ax2.barh(fert_data["Crop"], fert_data["Fertilizer (kg/acre)"], color="orange")
    ax2.set_title("Fertilizer Use")
    st.pyplot(fig2)
